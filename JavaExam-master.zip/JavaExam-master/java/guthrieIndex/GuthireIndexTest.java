package com.knight.exam.java.guthrieIndex;

/**
 * Created by sachinkeshav on 12/29/14.
 */
public class GuthireIndexTest {

    public static void main(String[] args) {
        System.out.println(GuthrieIndex.guthrieIndex(7));
        System.out.println(GuthrieIndex.guthrieIndex(1));
        System.out.println(GuthrieIndex.guthrieIndex(2));
        System.out.println(GuthrieIndex.guthrieIndex(3));
        System.out.println(GuthrieIndex.guthrieIndex(4));
        System.out.println(GuthrieIndex.guthrieIndex(42));
    }
}
