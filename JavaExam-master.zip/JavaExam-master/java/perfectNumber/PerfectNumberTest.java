package com.knight.exam.java.perfectNumber;

/**
 * Created by skushwaha on 12/29/14.
 */
public class PerfectNumberTest {

    public static void main(String[] args) {
        System.out.println(PerfectNumber.henry(1, 3));
    }
}
