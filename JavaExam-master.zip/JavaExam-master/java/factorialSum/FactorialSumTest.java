package com.knight.exam.java.factorialSum;

import java.util.Arrays;

/**
 * Created by skushwaha on 12/29/14.
 */
public class FactorialSumTest {

    public static void main(String[] args) {
        System.out.println(Arrays.toString(FactorialSum.solve10()));
    }
}
