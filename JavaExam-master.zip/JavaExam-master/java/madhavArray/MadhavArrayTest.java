package com.knight.exam.java.madhavArray;

/**
 * Created by sachinkeshav on 12/24/14.
 */
public class MadhavArrayTest {
    public static void main(String[] args) {
        int[] a = {2, 1, 1, 4, -1, -1};
        System.out.printf("The out put is %d", MadhavArray.isMadhavArray(a));
    }
}
