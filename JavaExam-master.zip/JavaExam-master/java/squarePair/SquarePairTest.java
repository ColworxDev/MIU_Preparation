package com.knight.exam.java.squarePair;

/**
 * Created by sachinkeshav on 12/28/14.
 */
public class SquarePairTest {
    public static void main(String[] args) {
        System.out.println(SquarePair.countSquarePair(new int[]{9, 0, 2, -5, 7}));
        System.out.println(SquarePair.countSquarePair(new int[]{9}));
    }
}
