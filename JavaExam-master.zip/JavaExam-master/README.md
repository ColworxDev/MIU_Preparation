# README #

This repo contains solutions to some common problems that involve manipulation of array. The solutions are written in Java programming language but the logic is pretty much same across all the languages.
